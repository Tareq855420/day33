<?php $__env->startSection('title'); ?>
    Java Script
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <?php echo $__env->make('includes.color-change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.images-change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h1 id="h1"></h1>
    <div id="content"></div>

    <script>
        var name = 'jenifer';
        document.write(name+' ');
        var data = [10, 20, 30];
        for (key in data)
        {
            document.write(data[2]+'<br>');
        }
        // var students = {name: 'Shanto', phone: '01234566', email: 'shanto@shantovaya.com'};
        var student = {name: 'Shanto', phone: '01234566', email: 'shanto@shantovaya.com'};

        var students = [
            {name: 'Shanto', phone: '0123456879', email: 'shanto@shantovaya.com'},
            {name: 'Arif', phone: '89598592958', email: 'arif@arifvaya.com'},
            {name: 'Sudipto', phone: '9999999999', email: 'sudipto@sudiptovaya.com'},
            {name: 'Jenifer', phone: '666666666', email: 'jenifer@jeniferapu.com'},
            {name: 'Sawon', phone: '222222222', email: 'sawon@sawonapu.com'},
            {name: 'Sazzad', phone: '444444444444', email: 'sazzad@sazzadvaya.com'},
        ];

        for (index in students)
        {
            document.write('Student name: '+students[index].name + '.student phone: '+students[index].phone+ 'student email: '+students[index].email+ '<br>');
        }

    </script>

    <script>

        function createDiv(height, width, color) {
            var div = document.createElement('div');
            div.style.height = height+'px';
            div.style.width = width+'px';
            div.style.backgroundColor = color+'';
            div.style.borderRadius = '100px';
            div.style.float = 'left';
            div.setAttribute('id', 'colorDiv');

            var content = document.getElementById('content');
            content.append(div);
        }

        // createDiv(300, 400, 'red');
        // createDiv(100, 200, 'green');
        // createDiv(300, 150, 'gray');
        // createDiv(300, 500, 'black');

        // function name() {
        //     // document.write('Tareq');
        //     alert('Hello World');
        // }
        //
        // name();

        // var firstName = 'Sawon';
        // var lastName = 'Akter';

        // function printName() {
        //     document.write(firstName+ ' ' +lastName);
        // }
        // printName();


        // getResult(10, 2);

        //
        function getResult(firstNumber, lastNumber) {
            document.write(firstNumber - lastNumber+'<br>');
        }
        //
        // getResult(100, 50);

        function getFullName(firstName, lastName) {
            var fullName = firstName+' '+lastName;
            // var h1 = document.getElementById('h1');
            // var h1 = document.getElementsByName(h1)[0];
            //
            // h1Element.innerHTML = fullName;

            document.getElementById('h1').innerHTML = fullName;
            // document.getElementsByTagName('h1')[0].innerHTML = fullName;
        }

        getFullName("Habibur", "Rahman");


        // var data = ['Shila', 'Sadia', 100, 10.25, 'bitm', 'Bangladesh', 200, 25.30];
        //
        // for (index in data)
        // {
        //     if (key > 1)
        //     {
        //         document.write(data[key]+'<br>')
        //     }
        //     // document.write(data[index]+'<br>');
        // }
        //
        //
        // var firstNumber = 'Sajjad';
        // var lastNumber = 'Hossain';
        //
        // document.write(firstNumber + ' &nbsp;&nbsp;&nbsp; ' + lastNumber);
        //
        //
        // document.write("Hello World");
        //
        // major rules for variable
        // * start with var
        // * a-z, A-Z, 0-9, $
        // * no number in first
        //
        // var name = 'Shanto';
        // var street = '22 street';
        // var Bangladesh = 'Hello Bangladesh';
        // var arif_name = 'His name is Arif';
        // var hellojenifer = "Hello Jenifer";
        //
        // var firstNumber = 10;
        // var bitm = 'bitm';
        // var price = 100.00;
        //
        // document.write(typeof(price));

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tareq\sixth_project\resources\views/js/js.blade.php ENDPATH**/ ?>