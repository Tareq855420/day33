<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/bootstrap.css')); ?>">
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-info">
    <div class="container">
        <a href="" class="navbar-brand">LOGO</a>
        <ul class="navbar-nav">
            <li><a href="" class="nav-link">Add Product</a></li>
            <li><a href="" class="nav-link">Java Script</a></li>
        </ul>
    </div>
</nav>
<?php echo $__env->yieldContent('body'); ?>
<?php /**PATH C:\xampp\htdocs\Tareq\sixth_project\resources\views/master.blade.php ENDPATH**/ ?>